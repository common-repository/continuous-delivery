<?php

namespace Dreitier\WordPress\ContinuousDelivery\Storage\S3;

class UnsupportedS3Uri extends \Exception
{
}
